

    // 1 - Validação de formulário
    const form = document.getElementById("formLab");
    const nome = document.getElementById("nome");
    const erroNome = document.getElementById("erroNome");

    form.addEventListener("submit", function(event) {
        erroNome.textContent = "";
        nome.classList.remove("input-erro");

        if (nome.value.trim() === "") {
            erroNome.textContent = "Por favor, digite seu nome.";
            // vou adicionar uma class no html para o css 
            nome.classList.add("input-erro");
            event.preventDefault();
        } else {
            alert("Formulário enviado com sucesso!");
            event.preventDefault(); // só para o exemplo não recarregar
        }
    });





    // 2 Manipulação de elementos
    const btnMensagem = document.getElementById("btnMensagem");
    const mensagem = document.getElementById("mensagem");

    btnMensagem.addEventListener("click", function() {
        mensagem.textContent = "O texto foi alterado com JavaScript!";
        mensagem.style.color = "blue";
        mensagem.style.fontWeight = "bold";
    });


    // 3 Efeitos e interações
    const btnFoto = document.getElementById("btnFoto");
    const foto = document.getElementById("foto");

    btnFoto.addEventListener("click", function() {
        if (foto.style.opacity === "0") {
            foto.style.opacity = "1";
        } else {
            foto.style.opacity = "0";
        }
    });


    // 4 Cálculos
    const n1 = document.getElementById("n1");
    const n2 = document.getElementById("n2");
    const btnSomar = document.getElementById("btnSomar");
    const resultado = document.getElementById("resultado");

    btnSomar.addEventListener("click", function() {
        const soma = Number(n1.value) + Number(n2.value);
        resultado.textContent = "Resultado: " + soma;
    });


    // 5 LocalStorage
    const nomeUsuario = document.getElementById("nomeUsuario");
    const btnSalvar = document.getElementById("btnSalvar");
    const boasVindas = document.getElementById("boasVindas");

    const nomeSalvo = localStorage.getItem("usuario");
    if (nomeSalvo) {
        boasVindas.textContent = " Bem-vindo de volta, " + nomeSalvo + "!";
    }

    btnSalvar.addEventListener("click", function() {
        localStorage.setItem("usuario", nomeUsuario.value);
        boasVindas.textContent = "Olá, " + nomeUsuario.value + "!";
    });


    // 6 Carrossel de imagens
    const slides = document.querySelectorAll(".carousel-slide");
    const prev = document.getElementById("prev");
    const next = document.getElementById("next");
    let index = 0;

    function showSlide(i) {
        slides.forEach(slide => slide.classList.remove("active"));
        slides[i].classList.add("active");
    }

    // Inicializa o primeiro slide
    showSlide(index);

    // Botão próximo
    next.addEventListener("click", function() {
        index = (index + 1) % slides.length;
        showSlide(index);
    });

    // Botão anterior
    prev.addEventListener("click", function() {
        index = (index - 1 + slides.length) % slides.length;
        showSlide(index);
    });

    // Auto-play opcional
    setInterval(() => {
        index = (index + 1) % slides.length;
        showSlide(index);
    }, 3000); // troca a cada 3 segundos


